package com.tienda.repository;

import com.tienda.model.Pedido;
import com.tienda.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    List<Pedido> findByUsuarioOrderByFechaDesc(Usuario u);
    List<Pedido> findAllByOrderByFechaDesc();
}
