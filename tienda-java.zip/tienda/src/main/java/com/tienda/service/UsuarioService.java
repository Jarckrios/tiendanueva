package com.tienda.service;

import com.tienda.model.Usuario;
import com.tienda.repository.UsuarioRepository;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UsuarioService implements UserDetailsService {
    private final UsuarioRepository repo;
    private final PasswordEncoder encoder;

    public UsuarioService(UsuarioRepository repo, PasswordEncoder encoder) {
        this.repo = repo;
        this.encoder = encoder;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Usuario u = repo.findByEmail(email.trim().toLowerCase())
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado"));
        return User.withUsername(u.getEmail())
                .password(u.getPassword())
                .authorities(u.getRol())
                .build();
    }

    public boolean emailExiste(String email) { return repo.existsByEmail(email.trim().toLowerCase()); }
    public boolean cedulaExiste(String cedula) { return repo.existsByCedula(cedula); }

    public Usuario registrar(Usuario u) {
        u.setEmail(u.getEmail().trim().toLowerCase());
        u.setRol("ROLE_CLIENTE"); // nunca se acepta el rol desde el formulario
        u.setPassword(encoder.encode(u.getPassword()));
        return repo.save(u);
    }
}
