package com.tienda.service;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;
import java.util.LinkedHashMap;
import java.util.Map;

/** Carrito en sesión: idProducto -> cantidad. */
@Component
@SessionScope
public class Carrito {
    private final Map<Long, Integer> items = new LinkedHashMap<>();

    public void agregar(Long id, int cantidad) { items.merge(id, cantidad, Integer::sum); }
    public void quitar(Long id) { items.remove(id); }
    public void vaciar() { items.clear(); }
    public Map<Long, Integer> getItems() { return items; }
    public boolean estaVacio() { return items.isEmpty(); }
}
