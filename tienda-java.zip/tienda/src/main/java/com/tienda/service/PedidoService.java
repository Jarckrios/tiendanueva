package com.tienda.service;

import com.tienda.model.*;
import com.tienda.repository.PedidoRepository;
import com.tienda.repository.ProductoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Service
public class PedidoService {
    private final PedidoRepository pedidos;
    private final ProductoRepository productos;

    public PedidoService(PedidoRepository pedidos, ProductoRepository productos) {
        this.pedidos = pedidos;
        this.productos = productos;
    }

    @Transactional
    public Pedido crear(Usuario u, String direccion, String metodoPago, Map<Long, Integer> items) {
        Pedido p = new Pedido();
        p.setUsuario(u);
        p.setDireccionEnvio(direccion);
        p.setMetodoPago(metodoPago);
        p.setFecha(LocalDateTime.now());
        p.setCodigoSeguimiento("TRK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        // Pago simulado: tarjeta/transferencia se marcan como PAGADO. Aquí se integraría Stripe/PayPal.
        p.setEstado("CONTRA_ENTREGA".equals(metodoPago) ? EstadoPedido.PENDIENTE : EstadoPedido.PAGADO);

        BigDecimal total = BigDecimal.ZERO;
        for (var e : items.entrySet()) {
            Producto pr = productos.findById(e.getKey())
                    .orElseThrow(() -> new IllegalStateException("Producto no disponible"));
            int cant = e.getValue();
            if (cant < 1 || pr.getStock() < cant)
                throw new IllegalStateException("Stock insuficiente para: " + pr.getNombre());
            pr.setStock(pr.getStock() - cant);

            ItemPedido it = new ItemPedido();
            it.setPedido(p);
            it.setProducto(pr);
            it.setCantidad(cant);
            it.setPrecioUnitario(pr.getPrecio());
            p.getItems().add(it);
            total = total.add(it.getSubtotal());
        }
        p.setTotal(total);
        return pedidos.save(p);
    }
}
