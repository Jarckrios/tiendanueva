package com.tienda.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/** Valida cédula ecuatoriana: 10 dígitos, provincia 01-24 o 30, algoritmo módulo 10. */
public class CedulaValidator implements ConstraintValidator<Cedula, String> {
    @Override
    public boolean isValid(String v, ConstraintValidatorContext ctx) {
        if (v == null || !v.matches("\\d{10}")) return false;
        int prov = Integer.parseInt(v.substring(0, 2));
        if ((prov < 1 || prov > 24) && prov != 30) return false;
        if (v.charAt(2) - '0' >= 6) return false;
        int suma = 0;
        for (int i = 0; i < 9; i++) {
            int d = v.charAt(i) - '0';
            if (i % 2 == 0) { d *= 2; if (d > 9) d -= 9; }
            suma += d;
        }
        int verificador = (10 - suma % 10) % 10;
        return verificador == v.charAt(9) - '0';
    }
}
