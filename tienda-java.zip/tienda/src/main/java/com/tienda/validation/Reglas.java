package com.tienda.validation;

/** Expresiones regulares reutilizables para validar campos. */
public final class Reglas {
    private Reglas() {}
    public static final String SOLO_LETRAS = "^[A-Za-zÁÉÍÓÚÜÑáéíóúüñ ]{2,50}$";
    public static final String SOLO_NUMEROS_10 = "^\\d{10}$";
}
