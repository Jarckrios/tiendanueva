package com.tienda.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = CedulaValidator.class)
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Cedula {
    String message() default "Cédula inválida: deben ser 10 dígitos numéricos válidos";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
