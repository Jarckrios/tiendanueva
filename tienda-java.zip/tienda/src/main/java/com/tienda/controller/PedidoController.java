package com.tienda.controller;

import com.tienda.model.Pedido;
import com.tienda.model.Usuario;
import com.tienda.repository.PedidoRepository;
import com.tienda.repository.UsuarioRepository;
import com.tienda.service.Carrito;
import com.tienda.service.PedidoService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Set;

@Controller
public class PedidoController {
    private static final Set<String> METODOS = Set.of("CONTRA_ENTREGA", "TARJETA", "TRANSFERENCIA");

    private final Carrito carrito;
    private final PedidoService service;
    private final PedidoRepository pedidos;
    private final UsuarioRepository usuarios;

    public PedidoController(Carrito carrito, PedidoService service, PedidoRepository pedidos, UsuarioRepository usuarios) {
        this.carrito = carrito;
        this.service = service;
        this.pedidos = pedidos;
        this.usuarios = usuarios;
    }

    @GetMapping("/checkout")
    public String checkoutForm(Authentication auth, Model m) {
        if (carrito.estaVacio()) return "redirect:/carrito";
        Usuario u = usuarios.findByEmail(auth.getName()).orElseThrow();
        m.addAttribute("direccion", u.getDireccion());
        return "checkout";
    }

    @PostMapping("/checkout")
    public String pagar(@RequestParam String direccion, @RequestParam String metodoPago,
                        Authentication auth, Model m, RedirectAttributes ra) {
        direccion = direccion.trim();
        if (direccion.length() < 5 || direccion.length() > 200 || !METODOS.contains(metodoPago)) {
            m.addAttribute("error", "Revisa la dirección (mín. 5 caracteres) y el método de pago");
            m.addAttribute("direccion", direccion);
            return "checkout";
        }
        if (carrito.estaVacio()) return "redirect:/carrito";
        Usuario u = usuarios.findByEmail(auth.getName()).orElseThrow();
        try {
            Pedido p = service.crear(u, direccion, metodoPago, carrito.getItems());
            carrito.vaciar();
            ra.addFlashAttribute("mensaje", "¡Pedido realizado! Código de seguimiento: " + p.getCodigoSeguimiento());
            return "redirect:/pedidos/" + p.getId();
        } catch (IllegalStateException ex) {
            m.addAttribute("error", ex.getMessage());
            m.addAttribute("direccion", direccion);
            return "checkout";
        }
    }

    @GetMapping("/pedidos")
    public String lista(Authentication auth, Model m) {
        Usuario u = usuarios.findByEmail(auth.getName()).orElseThrow();
        m.addAttribute("pedidos", pedidos.findByUsuarioOrderByFechaDesc(u));
        return "pedidos";
    }

    @GetMapping("/pedidos/{id}")
    public String detalle(@PathVariable Long id, Authentication auth, Model m) {
        Pedido p = pedidos.findById(id).orElse(null);
        if (p == null || !p.getUsuario().getEmail().equals(auth.getName())) return "redirect:/pedidos";
        m.addAttribute("pedido", p);
        return "pedido";
    }
}
