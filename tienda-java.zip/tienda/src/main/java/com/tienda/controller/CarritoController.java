package com.tienda.controller;

import com.tienda.dto.LineaCarrito;
import com.tienda.model.Producto;
import com.tienda.repository.ProductoRepository;
import com.tienda.service.Carrito;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/carrito")
public class CarritoController {
    private final Carrito carrito;
    private final ProductoRepository productos;

    public CarritoController(Carrito carrito, ProductoRepository productos) {
        this.carrito = carrito;
        this.productos = productos;
    }

    @GetMapping
    public String ver(Model m) {
        List<LineaCarrito> lineas = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;
        for (var e : carrito.getItems().entrySet()) {
            Producto p = productos.findById(e.getKey()).orElse(null);
            if (p == null) continue;
            LineaCarrito l = new LineaCarrito(p, e.getValue());
            lineas.add(l);
            total = total.add(l.getSubtotal());
        }
        m.addAttribute("lineas", lineas);
        m.addAttribute("total", total);
        return "carrito";
    }

    @PostMapping("/agregar/{id}")
    public String agregar(@PathVariable Long id, @RequestParam(defaultValue = "1") int cantidad, RedirectAttributes ra) {
        Producto p = productos.findById(id).orElse(null);
        if (p == null || cantidad < 1 || cantidad > 99) {
            ra.addFlashAttribute("error", "Cantidad o producto inválido");
            return "redirect:/";
        }
        int yaEnCarrito = carrito.getItems().getOrDefault(id, 0);
        if (yaEnCarrito + cantidad > p.getStock()) {
            ra.addFlashAttribute("error", "No hay stock suficiente de " + p.getNombre());
            return "redirect:/";
        }
        carrito.agregar(id, cantidad);
        ra.addFlashAttribute("mensaje", p.getNombre() + " agregado al carrito");
        return "redirect:/";
    }

    @PostMapping("/quitar/{id}")
    public String quitar(@PathVariable Long id) {
        carrito.quitar(id);
        return "redirect:/carrito";
    }
}
