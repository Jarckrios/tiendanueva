package com.tienda.controller;

import com.tienda.model.EstadoPedido;
import com.tienda.model.Pedido;
import com.tienda.model.Producto;
import com.tienda.repository.PedidoRepository;
import com.tienda.repository.ProductoRepository;
import com.tienda.repository.UsuarioRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final ProductoRepository productos;
    private final PedidoRepository pedidos;
    private final UsuarioRepository usuarios;

    public AdminController(ProductoRepository productos, PedidoRepository pedidos, UsuarioRepository usuarios) {
        this.productos = productos;
        this.pedidos = pedidos;
        this.usuarios = usuarios;
    }

    @GetMapping
    public String dashboard(Model m) {
        m.addAttribute("totalProductos", productos.count());
        m.addAttribute("totalPedidos", pedidos.count());
        m.addAttribute("totalUsuarios", usuarios.count());
        return "admin/dashboard";
    }

    // ----- productos -----
    @GetMapping("/productos")
    public String listaProductos(Model m) {
        m.addAttribute("productos", productos.findAll());
        return "admin/productos";
    }

    @GetMapping("/productos/nuevo")
    public String nuevo(Model m) {
        m.addAttribute("producto", new Producto());
        return "admin/producto-form";
    }

    @GetMapping("/productos/{id}/editar")
    public String editar(@PathVariable Long id, Model m) {
        m.addAttribute("producto", productos.findById(id).orElseThrow());
        return "admin/producto-form";
    }

    @PostMapping("/productos")
    public String guardar(@Valid @ModelAttribute("producto") Producto p, BindingResult br, RedirectAttributes ra) {
        if (br.hasErrors()) return "admin/producto-form";
        productos.save(p);
        ra.addFlashAttribute("mensaje", "Producto guardado");
        return "redirect:/admin/productos";
    }

    @PostMapping("/productos/{id}/eliminar")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra) {
        try {
            productos.deleteById(id);
            ra.addFlashAttribute("mensaje", "Producto eliminado");
        } catch (Exception e) {
            ra.addFlashAttribute("error", "No se puede eliminar: tiene pedidos asociados (pon el stock en 0)");
        }
        return "redirect:/admin/productos";
    }

    // ----- pedidos -----
    @GetMapping("/pedidos")
    public String listaPedidos(Model m) {
        m.addAttribute("pedidos", pedidos.findAllByOrderByFechaDesc());
        m.addAttribute("estados", EstadoPedido.values());
        return "admin/pedidos";
    }

    @PostMapping("/pedidos/{id}/estado")
    public String cambiarEstado(@PathVariable Long id, @RequestParam EstadoPedido estado, RedirectAttributes ra) {
        Pedido p = pedidos.findById(id).orElseThrow();
        p.setEstado(estado);
        pedidos.save(p);
        ra.addFlashAttribute("mensaje", "Estado actualizado");
        return "redirect:/admin/pedidos";
    }
}
