package com.tienda.controller;

import com.tienda.repository.ProductoRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CatalogoController {
    private final ProductoRepository productos;

    public CatalogoController(ProductoRepository productos) { this.productos = productos; }

    @GetMapping({"/", "/catalogo"})
    public String catalogo(@RequestParam(defaultValue = "") String q, Model m) {
        m.addAttribute("productos", productos.findByNombreContainingIgnoreCase(q.trim()));
        m.addAttribute("q", q);
        return "catalogo";
    }
}
