package com.tienda.controller;

import com.tienda.model.Usuario;
import com.tienda.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {
    private final UsuarioService service;

    public AuthController(UsuarioService service) { this.service = service; }

    @GetMapping("/login")
    public String login() { return "login"; }

    @GetMapping("/registro")
    public String registroForm(Model m) {
        m.addAttribute("usuario", new Usuario());
        return "registro";
    }

    @PostMapping("/registro")
    public String registrar(@Valid @ModelAttribute("usuario") Usuario u, BindingResult br, RedirectAttributes ra) {
        if (u.getEmail() != null && service.emailExiste(u.getEmail()))
            br.rejectValue("email", "dup", "Ese correo ya está registrado");
        if (u.getCedula() != null && service.cedulaExiste(u.getCedula()))
            br.rejectValue("cedula", "dup", "Esa cédula ya está registrada");
        if (br.hasErrors()) return "registro";
        service.registrar(u);
        ra.addFlashAttribute("mensaje", "Cuenta creada. Ya puedes iniciar sesión.");
        return "redirect:/login";
    }
}
