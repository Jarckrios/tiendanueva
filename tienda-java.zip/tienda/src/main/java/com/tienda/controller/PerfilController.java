package com.tienda.controller;

import com.tienda.dto.PerfilForm;
import com.tienda.model.Usuario;
import com.tienda.repository.UsuarioRepository;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/perfil")
public class PerfilController {
    private final UsuarioRepository usuarios;

    public PerfilController(UsuarioRepository usuarios) { this.usuarios = usuarios; }

    @GetMapping
    public String ver(Authentication auth, Model m) {
        Usuario u = usuarios.findByEmail(auth.getName()).orElseThrow();
        PerfilForm f = new PerfilForm();
        f.setNombre(u.getNombre()); f.setApellido(u.getApellido());
        f.setTelefono(u.getTelefono()); f.setDireccion(u.getDireccion());
        m.addAttribute("form", f);
        m.addAttribute("usuario", u);
        return "perfil";
    }

    @PostMapping
    public String guardar(@Valid @ModelAttribute("form") PerfilForm f, BindingResult br,
                          Authentication auth, Model m, RedirectAttributes ra) {
        Usuario u = usuarios.findByEmail(auth.getName()).orElseThrow();
        if (br.hasErrors()) { m.addAttribute("usuario", u); return "perfil"; }
        u.setNombre(f.getNombre()); u.setApellido(f.getApellido());
        u.setTelefono(f.getTelefono()); u.setDireccion(f.getDireccion());
        usuarios.save(u);
        ra.addFlashAttribute("mensaje", "Perfil actualizado");
        return "redirect:/perfil";
    }
}
