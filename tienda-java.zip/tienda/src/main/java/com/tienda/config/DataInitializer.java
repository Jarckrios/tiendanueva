package com.tienda.config;

import com.tienda.model.Producto;
import com.tienda.model.Usuario;
import com.tienda.repository.ProductoRepository;
import com.tienda.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.math.BigDecimal;

/** Crea un administrador y productos de ejemplo la primera vez que arranca. */
@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner init(UsuarioRepository usuarios, ProductoRepository productos, PasswordEncoder enc) {
        return args -> {
            if (!usuarios.existsByEmail("admin@tienda.com")) {
                Usuario a = new Usuario();
                a.setCedula("1710034065");
                a.setNombre("Administrador");
                a.setApellido("Tienda");
                a.setEmail("admin@tienda.com");
                a.setTelefono("0999999999");
                a.setDireccion("Oficina central");
                a.setPassword(enc.encode("Admin123"));
                a.setRol("ROLE_ADMIN");
                usuarios.save(a);
            }
            if (productos.count() == 0) {
                crear(productos, "Audífonos Bluetooth", "Inalámbricos con estuche de carga", "19.99", 50);
                crear(productos, "Reloj inteligente", "Monitor de actividad y notificaciones", "34.50", 30);
                crear(productos, "Mochila impermeable", "Capacidad 25L, puerto USB", "24.90", 40);
                crear(productos, "Lámpara LED de escritorio", "3 niveles de brillo", "12.75", 60);
            }
        };
    }

    private void crear(ProductoRepository r, String n, String d, String p, int s) {
        Producto x = new Producto();
        x.setNombre(n); x.setDescripcion(d); x.setPrecio(new BigDecimal(p)); x.setStock(s);
        r.save(x);
    }
}
