package com.tienda.model;

public enum EstadoPedido {
    PENDIENTE, PAGADO, PREPARANDO, ENVIADO, EN_CAMINO, ENTREGADO, CANCELADO
}
