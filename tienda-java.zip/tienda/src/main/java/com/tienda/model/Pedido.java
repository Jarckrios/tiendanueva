package com.tienda.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter @Setter
public class Pedido {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(optional = false) private Usuario usuario;
    private LocalDateTime fecha;
    @Column(precision = 10, scale = 2) private BigDecimal total;
    @Enumerated(EnumType.STRING) private EstadoPedido estado;
    private String direccionEnvio;
    private String metodoPago;
    private String codigoSeguimiento;

    @OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<ItemPedido> items = new ArrayList<>();
}
