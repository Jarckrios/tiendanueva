package com.tienda.model;

import com.tienda.validation.Cedula;
import com.tienda.validation.Reglas;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter @Setter
public class Usuario {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Cedula
    @Column(unique = true, nullable = false, length = 10)
    private String cedula;

    @NotBlank(message = "El nombre es obligatorio")
    @Pattern(regexp = Reglas.SOLO_LETRAS, message = "El nombre solo admite letras (2 a 50)")
    private String nombre;

    @NotBlank(message = "El apellido es obligatorio")
    @Pattern(regexp = Reglas.SOLO_LETRAS, message = "El apellido solo admite letras (2 a 50)")
    private String apellido;

    @NotBlank(message = "El correo es obligatorio")
    @Email(message = "Correo inválido")
    @Column(unique = true, nullable = false)
    private String email;

    @NotBlank(message = "El teléfono es obligatorio")
    @Pattern(regexp = Reglas.SOLO_NUMEROS_10, message = "El teléfono debe tener 10 dígitos numéricos")
    private String telefono;

    @Size(max = 200, message = "Dirección demasiado larga")
    private String direccion;

    @NotBlank(message = "La contraseña es obligatoria")
    @Size(min = 6, message = "La contraseña debe tener al menos 6 caracteres")
    private String password;

    @Column(nullable = false)
    private String rol = "ROLE_CLIENTE";
}
