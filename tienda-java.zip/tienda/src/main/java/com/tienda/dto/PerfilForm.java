package com.tienda.dto;

import com.tienda.validation.Reglas;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class PerfilForm {
    @NotBlank(message = "El nombre es obligatorio")
    @Pattern(regexp = Reglas.SOLO_LETRAS, message = "El nombre solo admite letras (2 a 50)")
    private String nombre;

    @NotBlank(message = "El apellido es obligatorio")
    @Pattern(regexp = Reglas.SOLO_LETRAS, message = "El apellido solo admite letras (2 a 50)")
    private String apellido;

    @NotBlank(message = "El teléfono es obligatorio")
    @Pattern(regexp = Reglas.SOLO_NUMEROS_10, message = "El teléfono debe tener 10 dígitos numéricos")
    private String telefono;

    @Size(max = 200, message = "Dirección demasiado larga")
    private String direccion;
}
