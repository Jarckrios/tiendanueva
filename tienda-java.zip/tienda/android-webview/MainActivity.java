package com.tienda.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** App Android mínima: muestra la tienda web dentro de un WebView (esto genera el APK). */
public class MainActivity extends Activity {
    // Emulador Android -> tu PC: 10.0.2.2. En producción: tu URL https real.
    private static final String URL_TIENDA = "http://10.0.2.2:8080";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient()); // mantiene la navegación dentro de la app
        setContentView(web);
        web.loadUrl(URL_TIENDA);
    }
}
